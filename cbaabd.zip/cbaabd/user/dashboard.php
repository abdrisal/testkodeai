<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('user');
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>User Dashboard</title>
<link rel="stylesheet" href="/cbaabd/assets/style.css">
</head>
<body class="dashboard-body">
<aside class="sidebar">
<div class="brand">User</div>
<nav>
<a href="/cbaabd/user/dashboard.php" class="nav-item"><span class="icon">🏠</span><span class="label">Dashboard</span></a>
<a href="/cbaabd/logout.php" class="nav-item"><span class="icon">🚪</span><span class="label">Logout</span></a>
</nav>
</aside>
<main class="content">
<h1>Selamat datang, <?= htmlspecialchars($_SESSION['username']) ?></h1>
<p>Dashboard User.</p>
</main>
</body>
</html>
