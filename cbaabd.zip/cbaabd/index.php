<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    if ($_SESSION['role'] === 'admin') header('Location: /cbaabd/admin/dashboard.php');
    else header('Location: /cbaabd/user/dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? AND role = ?');
    $stmt->execute([$email, $role]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];
        if ($user['role'] === 'admin') header('Location: /cbaabd/admin/dashboard.php');
        else header('Location: /cbaabd/user/dashboard.php');
        exit;
    } else {
        $error = 'Email, password, atau role salah.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Login</title>
<link rel="stylesheet" href="/cbaabd/assets/style.css">
</head>
<body class="auth-body">
<div class="auth-card">
<h2>Login</h2>
<?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
<form method="post">
<label>Email</label>
<input type="email" name="email" required>
<label>Password</label>
<input type="password" name="password" required>
<label>Role</label>
<select name="role" required>
<option value="user">User</option>
<option value="admin">Admin</option>
</select>
<button type="submit">Masuk</button>
</form>
<p>Belum punya akun? <a href="/cbaabd/register.php">Register</a></p>
</div>
</body>
</html>
