<?php
session_start();

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /cbaabd/index.php');
        exit;
    }
}

function requireRole($role) {
    requireLogin();
    if ($_SESSION['role'] !== $role) {
        header('Location: /cbaabd/index.php');
        exit;
    }
}

function logout() {
    session_unset();
    session_destroy();
    header('Location: /cbaabd/index.php');
    exit;
}
?>