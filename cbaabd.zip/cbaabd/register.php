<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    header('Location: /cbaabd/index.php');
    exit;
}

$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'user';

    if ($username === '' || $email === '' || $password === '') {
        $error = 'Semua field wajib diisi.';
    } elseif (!in_array($role, ['admin','user'], true)) {
        $error = 'Role tidak valid.';
    } else {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? OR username = ?');
        $stmt->execute([$email, $username]);
        if ($stmt->fetch()) {
            $error = 'Username atau email sudah terdaftar.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('INSERT INTO users (username, email, password, role) VALUES (?,?,?,?)');
            $stmt->execute([$username, $email, $hash, $role]);
            $success = 'Registrasi berhasil. Silakan login.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Register</title>
<link rel="stylesheet" href="/cbaabd/assets/style.css">
</head>
<body class="auth-body">
<div class="auth-card">
<h2>Register</h2>
<?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="success"><?= htmlspecialchars($success) ?></p><?php endif; ?>
<form method="post">
<label>Username</label>
<input type="text" name="username" required>
<label>Email</label>
<input type="email" name="email" required>
<label>Password</label>
<input type="password" name="password" required>
<label>Role</label>
<select name="role" required>
<option value="user">User</option>
<option value="admin">Admin</option>
</select>
<button type="submit">Daftar</button>
</form>
<p>Sudah punya akun? <a href="/cbaabd/index.php">Login</a></p>
</div>
</body>
</html>
