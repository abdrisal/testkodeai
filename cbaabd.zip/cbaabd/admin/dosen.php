﻿<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');
?>
<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><title><?= ucfirst("dosen") ?></title><link rel="stylesheet" href="/cbaabd/assets/style.css"></head>
<body class="dashboard-body">
<aside class="sidebar">
<div class="brand">Admin</div>
<nav>
<a href="/cbaabd/admin/dashboard.php" class="nav-item"><span class="icon">🏠</span><span class="label">Dashboard</span></a>
<a href="/cbaabd/admin/mahasiswa.php" class="nav-item"><span class="icon">🎓</span><span class="label">Mahasiswa</span></a>
<a href="/cbaabd/admin/dosen.php" class="nav-item"><span class="icon">👨‍🏫</span><span class="label">Dosen</span></a>
<a href="/cbaabd/admin/matakuliah.php" class="nav-item"><span class="icon">📚</span><span class="label">Mata Kuliah</span></a>
<a href="/cbaabd/logout.php" class="nav-item"><span class="icon">🚪</span><span class="label">Logout</span></a>
</nav>
</aside>
<main class="content"><h1>dosen</h1><p>Halaman dosen (placeholder). Koneksi DB siap digunakan.</p></main>
</body>
</html>
